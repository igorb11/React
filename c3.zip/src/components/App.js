import React from 'react';
import {Car} from './Car';
import {Comments} from './Comments';

export class App extends React.Component{
    render(){
        var registracija={
            grad:'Skopje',
            oznaka:'Sk-99990vm'
        }
        var vozila = [
            {brand:'Ford',model:'Ka',year:1997,number:12345567,registracija:registracija},
            {brand:'Opel',model:'Astra',year:2001,number:1234335567,registracija:registracija},
            {brand:'Nisan',model:'Patrol',year:1999,number:12345567,registracija:registracija},


        ]



        return(
            <div>
                {/* <Car vozila={vozila} */}
                <Comments date='11-11-2012' broj={5} isValid={true}/>
            </div>
        )
    }
}