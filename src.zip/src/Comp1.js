import React from 'react';

export class Comp1 extends React.Component {
    render(){
        return(
            <h1>Text1</h1>
        )
    }
}