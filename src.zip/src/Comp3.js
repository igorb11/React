import React from 'react';

export class Comp3 extends React.Component {
    render(){
        return(
            <h1>Text3</h1>
        )
    }
}