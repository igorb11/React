import React from 'react';

export class Comp2 extends React.Component {
    render(){
        return(
            <h1>Text2</h1>
        )
    }
}