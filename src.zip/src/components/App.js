import React from 'react';
import {Welcome} from './Welcome';
import {Hotel} from './Hotel';
import {User} from './../User';
import {FruitList} from './FruitList'

export class App extends React.Component {
  render(){
    var godiniIgor =25;
    var godiniPero=18; 
    var hasVacancy=true;
    var fruits= ['orange','peach','apple','banana']
    var user = {
      ime:'Igor',
      prezime:'Bachev',
      email:'ibacev95@gmail.com',
      image:'https://www.howtogeek.com/wp-content/uploads/2018/06/shutterstock_1006988770.png'
    }
    return(<div>
      <h2>Hello</h2>
      <Welcome name={'Igor'} ageIgor={godiniIgor} />
      <Welcome name={'Igor'}  age={godiniPero}/>
      <Hotel imaSobi={hasVacancy}/>
      <br/>
      <User korisnik={user}/>
      <hr/>
      <FruitList lista={fruits} />
      </div>
    )
  }
} export default App