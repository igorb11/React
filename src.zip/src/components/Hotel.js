import React from 'react';

export class Hotel extends React.Component {
    render(){
        console.log(this.props)
        return(
            <div>
           {/* {this.props.imaSobi ? <h2>Ima sobi</h2> : <h2>Nemame sobi</h2>} */}
           {this.props.imaSobi && <h2>Imame sobi</h2>}
           </div>
        )
    }
}