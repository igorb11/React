import React from 'react';
import {Login} from './Login';


export function App(){
  return(
    <div id='app'>
      <Login/>
    </div>
  )
}