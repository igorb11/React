import React from 'react';
import {Movies} from './Movies';
import {Sliki} from './Sliki'; 
import './style.css';
export class App extends React.Component{
  render(){
      
    var lista = ['The Shawshank Redemption (1994)','Whiplash (2014)','Interstellar (2014)']
    var sliki = ['https://m.media-amazon.com/images/M/MV5BMDFkYTc0MGEtZmNhMC00ZDIzLWFmNTEtODM1ZmRlYWMwMWFmXkEyXkFqcGdeQXVyMTMxODk2OTU@._V1_.jpg','https://m.media-amazon.com/images/M/MV5BNjM4OTQ4NjctZTYxYS00NWJiLThiZGItZjI4NjRhYWFhZTBiXkEyXkFqcGdeQXVyNTc3MjUzNTI@._V1_.jpg','https://images-na.ssl-images-amazon.com/images/I/91kFYg4fX3L.jpg']
    return(
      <div>
        <Movies list = {lista}/>
         <Sliki sliki={sliki}/>

        
      </div>
    )
  }
}