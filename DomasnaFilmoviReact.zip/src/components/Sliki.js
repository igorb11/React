import React from 'react';

export class Sliki extends React.Component{
    render(){
        return(
            <div id='pics'>
            {this.props.sliki.map((row,i)=>(
                  <li><img src={row}></img>   </li>
              )
              )}
       </div>
        )
    }
}