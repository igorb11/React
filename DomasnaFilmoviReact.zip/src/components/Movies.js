import React from 'react';
import { Sliki } from './Sliki';

export class Movies extends React.Component {
    render() {
        console.log(this.props.list)
        return (
            <div>
              {this.props.list.map((row,i)=>(
                    <li>{row}</li>
                )
                )}
         </div>
        )
    }
}